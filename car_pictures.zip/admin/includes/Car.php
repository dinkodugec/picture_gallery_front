<?php



class Car 
{
      public function run()
      {
     
         echo "Hello Lyquer";   
      }





}